A Pen created at CodePen.io. You can find this one at http://codepen.io/mdixondesigns/pen/PPEJwz.

 So pumped after the new Star Wars trailer! Can't wait for December!